from django.shortcuts import render
from django.shortcuts import redirect
from django.views import View
from django.http import Http404
from django import forms
from news.models import get_date_list
from news.models import get_news_item
from news.models import add_news_item

class HomeView(View):
    def get(self, request, *args, **kwargs):
        return redirect('/news/')


class SearchForm(forms.Form):
    q = forms.CharField(max_length=256, label='Search', required=False)


class ListView(View):
    def get(self, request, *args, **kwargs):
        form = SearchForm(request.GET)
        q = ''
        if form.is_valid():
            q = form.cleaned_data.get('q')
        items = get_date_list(q)
        return render(request, 'list.html', context={'list': items, 'form': form})


class ItemView(View):
    def get(self, request, *args, **kwargs):
        item = get_news_item(kwargs['id'])
        if item:
            return render(request, 'item.html', context={'item': item})
        raise Http404


class ItemForm(forms.Form):
    title = forms.CharField(max_length=256, label='Title')
    text = forms.CharField(max_length=1024, label='Text', widget=forms.Textarea)


class ItemCreate(View):

    def get(self, request):
        form = ItemForm()
        return render(request, 'create.html', context={'form': form})

    def post(self, request):
        form = ItemForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            item = {'title': data.get('title'), 'text': data.get('text')}
            add_news_item(item)
            return redirect('/news/')

        return render(request, 'create.html', context={'form': form})
