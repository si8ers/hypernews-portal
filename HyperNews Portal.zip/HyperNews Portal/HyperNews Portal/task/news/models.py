from django.db import models
import os
from django.conf import settings
import json
import time


def get_news_list():
    with open(os.path.join(settings.BASE_DIR, settings.NEWS_JSON_PATH), 'rt') as f:
        items = json.load(f)
        return items
    return None


def get_date_list(q=None):
    items = get_news_list()
    items = sorted(items, key=lambda item: item['created'], reverse=True)
    list = {}
    for item in items:
        if not q or item['title'].lower().find(q.lower()) > -1:
            date, time = item['created'].split()
            list.setdefault(date, [])
            list[date].append(item)
    return list



def get_news_item(id):
    items = get_news_list()
    for item in items:
        if item['link'] == id:
            return item
    return None


def add_news_item(item):
    items = get_news_list()
    item['link'] = str(round(time.time()))
    item['created'] = time.strftime('%Y-%m-%d %H:%M:%S')
    items.append(item)
    with open(os.path.join(settings.BASE_DIR, settings.NEWS_JSON_PATH), 'wt') as f:
        json.dump(items, f)
