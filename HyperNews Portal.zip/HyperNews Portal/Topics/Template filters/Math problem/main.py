template = """
<html>
  <div> a + b + c = {{ a | add:b | add:c }} </div>
</html>
"""
