template = """
<html>
  <h2>{{ blog_name | title }}</h2>
</html>
"""
