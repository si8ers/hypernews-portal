import collections


queue = collections.deque()
n = int(input())
while n > 0:
    n -= 1
    act = input()
    if act == 'DEQUEUE':
        if queue:
            queue.pop()
    elif act.find('ENQUEUE ') == 0:
        queue.appendleft(act.replace('ENQUEUE ', '', 1))
while queue:
    print(queue.pop())
