import collections


queue = collections.deque()
n = int(input())
while n > 0:
    n -= 1
    act = input()
    if act == 'SOLVED':
        if queue:
            queue.pop()
    elif act.find('ISSUE ') == 0:
        queue.appendleft(act.replace('ISSUE ', '', 1))
while queue:
    print(queue.pop())
