reversed_queue = deque()
for i in my_queue:
    reversed_queue.appendleft(i)
