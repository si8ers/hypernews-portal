template = """
<html>
  <audio src="{{ MEDIA_URL }}/mp3/django.mp3"></audio>
</html>
"""
