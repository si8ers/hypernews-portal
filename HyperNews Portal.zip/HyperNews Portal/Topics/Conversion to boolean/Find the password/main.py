def solve():
    print(wrong_password(0))
