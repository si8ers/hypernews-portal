def xor(a, b):
    if a and not b:
        return a
    if not a and b:
        return b
    return False
