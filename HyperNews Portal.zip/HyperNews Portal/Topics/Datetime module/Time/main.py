print(some_date.time())
