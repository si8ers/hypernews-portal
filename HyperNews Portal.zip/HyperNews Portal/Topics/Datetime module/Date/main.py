print(some_date.date())
